while true
do
echo "Starting Kerm-Md!"
node .
done